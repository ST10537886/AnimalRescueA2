/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.co.wildlife;

/**
 *
 * @author maake
 */
public class Wildliferescuesystem2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
