/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.co.wildlife;

/**
 *
 * @author maake
 */
public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateRescueSummary();
}

