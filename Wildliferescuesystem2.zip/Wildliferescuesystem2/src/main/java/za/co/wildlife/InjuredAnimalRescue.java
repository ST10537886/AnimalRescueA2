/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author maake
 */
package za.co.wildlife;

public class InjuredAnimalRescue extends RescueCase {

    private final String injuryDescription;
    private final double veterinaryTreatmentCost;
    private final boolean surgeryRequired;

    public InjuredAnimalRescue(String rescueCaseId, String animalName,
                               String species, String rescueLocation,
                               String assignedRanger, int rescueDays,
                               double dailyCareCost, String injuryDescription,
                               double veterinaryTreatmentCost,
                               boolean surgeryRequired) {

        super(rescueCaseId, animalName, species, rescueLocation,
              assignedRanger, rescueDays, dailyCareCost);

        if (injuryDescription == null
                || injuryDescription.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Injury description cannot be blank.");
        }

        if (!Double.isFinite(veterinaryTreatmentCost)
                || veterinaryTreatmentCost < 0) {
            throw new IllegalArgumentException(
                    "Veterinary treatment cost must be finite and cannot be negative.");
        }

        this.injuryDescription = injuryDescription.trim();
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + veterinaryTreatmentCost;

        if (surgeryRequired) {
            total += 5000;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        // Assumption: surgery cases are Critical; other injury cases are High.
        return surgeryRequired ? "Critical" : "High";
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                "Injury Description: %s%n"
                + "Veterinary Treatment Cost: R%.2f%n"
                + "Surgery Required: %s%n",
                injuryDescription,
                veterinaryTreatmentCost,
                surgeryRequired ? "Yes" : "No");
    }
}