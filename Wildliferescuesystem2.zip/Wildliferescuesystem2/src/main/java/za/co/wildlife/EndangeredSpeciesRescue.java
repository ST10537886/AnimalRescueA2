/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlife;

/**
 *
 * @author maake
 */

public class EndangeredSpeciesRescue extends RescueCase {

    private final String conservationClassification;
    private final double securityCost;
    private final boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String rescueCaseId, String animalName,
                                   String species, String rescueLocation,
                                   String assignedRanger, int rescueDays,
                                   double dailyCareCost,
                                   String conservationClassification,
                                   double securityCost,
                                   boolean specialistTeamRequired) {

        super(rescueCaseId, animalName, species, rescueLocation,
              assignedRanger, rescueDays, dailyCareCost);

        if (conservationClassification == null
                || conservationClassification.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Conservation classification cannot be blank.");
        }

        if (!Double.isFinite(securityCost) || securityCost < 0) {
            throw new IllegalArgumentException(
                    "Security cost must be finite and cannot be negative.");
        }

        this.conservationClassification =
                conservationClassification.trim();
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + securityCost;

        if (specialistTeamRequired) {
            total += 8000;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        // Assumption: specialist team cases are Critical; others are High.
        return specialistTeamRequired ? "Critical" : "High";
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                "Conservation Classification: %s%n"
                + "Security Cost: R%.2f%n"
                + "Specialist Team Required: %s%n",
                conservationClassification,
                securityCost,
                specialistTeamRequired ? "Yes" : "No");
    }
}
