/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlife;
import java.util.Scanner;

/**
 *
 * @author maake
 */
public class InputHelper {

    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readRequiredText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("This field cannot be blank.");
        }
    }

    public int readInt(String prompt, int minimum, int maximum) {
        while (true) {
            System.out.print(prompt);

            try {
                int value = Integer.parseInt(scanner.nextLine().trim());

                if (value >= minimum && value <= maximum) {
                    return value;
                }

                System.out.printf(
                        "Enter a whole number between %d and %d.%n",
                        minimum, maximum);

            } catch (NumberFormatException e) {
                System.out.println("Enter a valid whole number.");
            }
        }
    }

    public double readCost(String prompt, boolean allowZero) {
        while (true) {
            System.out.print(prompt);

            try {
                double value =
                        Double.parseDouble(scanner.nextLine().trim());

                if (Double.isFinite(value)
                        && (allowZero ? value >= 0 : value > 0)) {
                    return value;
                }

                System.out.println(allowZero
                        ? "Enter a finite amount of zero or more."
                        : "Enter a finite amount greater than zero.");

            } catch (NumberFormatException e) {
                System.out.println(
                        "Enter a valid amount, for example 250.50.");
            }
        }
    }

    public boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (yes/no): ");
            String value = scanner.nextLine().trim();

            if (value.equalsIgnoreCase("yes")
                    || value.equalsIgnoreCase("y")) {
                return true;
            }

            if (value.equalsIgnoreCase("no")
                    || value.equalsIgnoreCase("n")) {
                return false;
            }

            System.out.println("Please enter yes or no.");
        }
    }
}
