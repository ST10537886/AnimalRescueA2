/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlife;
import java.util.ArrayList;

/**
 *
 * @author maake
 */
public class RescueManager {

    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    public boolean addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null) {
            throw new IllegalArgumentException("Rescue case cannot be null.");
        }

        if (findRescueCase(rescueCase.getRescueCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    public RescueCase findRescueCase(String rescueCaseId) {
        if (rescueCaseId == null || rescueCaseId.trim().isEmpty()) {
            return null;
        }

        String searchId = rescueCaseId.trim();

        for (RescueCase rescueCase : rescueCases) {
            if (rescueCase.getRescueCaseId().equalsIgnoreCase(searchId)) {
                return rescueCase;
            }
        }

        return null;
    }

    public boolean updateRescueStatus(String rescueCaseId, String status) {
        RescueCase rescueCase = findRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.setRescueStatus(status);
        return true;
    }

    public boolean startRescue(String rescueCaseId) {
        RescueCase rescueCase = findRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.startRescue();
        return true;
    }

    public boolean completeRescue(String rescueCaseId) {
        RescueCase rescueCase = findRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.completeRescue();
        return true;
    }

    public int getTotalCases() {
        return rescueCases.size();
    }

    public double getTotalEstimatedCost() {
        double total = 0;

        for (RescueCase rescueCase : rescueCases) {
            total += rescueCase.calculateTotalCost();
        }

        return total;
    }

    public String displayAllRescueCases() {
        if (rescueCases.isEmpty()) {
            return "No rescue cases recorded.\n";
        }

        StringBuilder details = new StringBuilder();

        for (RescueCase rescueCase : rescueCases) {
            details.append("----------------------------------------\n");
            details.append(rescueCase.generateRescueSummary());
            details.append("Animal Name: ")
                    .append(rescueCase.getAnimalName()).append("\n");
            details.append("Rescue Location: ")
                    .append(rescueCase.getRescueLocation()).append("\n");
            details.append("Rescue Days: ")
                    .append(rescueCase.getRescueDays()).append("\n");
            details.append(String.format(
                    "Daily Care Cost: R%.2f%n",
                    rescueCase.getDailyCareCost()));
            details.append(rescueCase.getSpecificDetails());
        }

        return details.toString();
    }

    public String generateReport() {
        StringBuilder report = new StringBuilder();

        report.append("========================================\n");
        report.append("WILDLIFE RESCUE REPORT\n");
        report.append("========================================\n");

        if (rescueCases.isEmpty()) {
            report.append("No rescue cases recorded.\n");
        }

        for (RescueCase rescueCase : rescueCases) {
            report.append(rescueCase.generateRescueSummary());
            report.append("Rescue Location: ")
                    .append(rescueCase.getRescueLocation()).append("\n");
            report.append("----------------------------------------\n");
        }

        report.append("Total Rescue Cases: ")
                .append(getTotalCases()).append("\n");
        report.append(String.format(
                "Total Estimated Rescue Cost: R%.2f%n",
                getTotalEstimatedCost()));

        return report.toString();
    }
}