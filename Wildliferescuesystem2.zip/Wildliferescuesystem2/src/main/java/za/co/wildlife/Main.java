/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlife;
import java.util.Scanner;

/**
 *
 * @author maake
 */

public class Main {

    public static void main(String[] args) {
        RescueManager manager = new RescueManager();

        try (Scanner scanner = new Scanner(System.in)) {
            InputHelper input = new InputHelper(scanner);
            boolean running = true;

            while (running) {
                System.out.println(
                        "\n========================================");
                System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
                System.out.println(
                        "========================================");
                System.out.println("1. Create Rescue Case");
                System.out.println("2. Search Rescue Case");
                System.out.println("3. Update Rescue Status");
                System.out.println("4. Display All Rescue Cases");
                System.out.println("5. Rescue Report");
                System.out.println("6. Exit");

                int choice = input.readInt("Select an option: ", 1, 6);

                try {
                    switch (choice) {
                        case 1:
                            createRescueCase(input, manager);
                            break;
                        case 2:
                            searchRescueCase(input, manager);
                            break;
                        case 3:
                            updateRescueStatus(input, manager);
                            break;
                        case 4:
                            System.out.println(
                                    manager.displayAllRescueCases());
                            break;
                        case 5:
                            System.out.println(manager.generateReport());
                            break;
                        case 6:
                            running = false;
                            System.out.println("Goodbye.");
                            break;
                        default:
                            System.out.println("Invalid option.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Unable to save: " + e.getMessage());
                }
            }
        }
    }

    private static void createRescueCase(InputHelper input,
                                         RescueManager manager) {
        System.out.println("\nRESCUE CASE TYPES");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int type = input.readInt("Select rescue type: ", 1, 3);

        String id;

        while (true) {
            id = input.readRequiredText("Rescue Case ID: ");

            if (manager.findRescueCase(id) == null) {
                break;
            }

            System.out.println(
                    "That ID already exists. Enter a different ID.");
        }

        String animalName = input.readRequiredText("Animal Name: ");
        String species = input.readRequiredText("Species: ");
        String location = input.readRequiredText("Rescue Location: ");
        String ranger = input.readRequiredText("Assigned Ranger: ");

        int days = input.readInt(
                "Number of Rescue Days: ", 1, Integer.MAX_VALUE);

        double dailyCost = input.readCost(
                "Daily Care Cost (R): ", false);

        RescueCase rescueCase;

        switch (type) {
            case 1:
                String injury = input.readRequiredText(
                        "Injury Description: ");

                double treatmentCost = input.readCost(
                        "Veterinary Treatment Cost (R): ", true);

                boolean surgery = input.readYesNo("Surgery Required");

                rescueCase = new InjuredAnimalRescue(
                        id, animalName, species, location, ranger,
                        days, dailyCost, injury, treatmentCost, surgery);
                break;

            case 2:
                int age = input.readInt(
                        "Estimated Age (Months): ", 0, Integer.MAX_VALUE);

                double feedingCost = input.readCost(
                        "Total Feeding Cost (R): ", true);

                boolean fosterCare = input.readYesNo(
                        "Foster Care Required");

                rescueCase = new OrphanedAnimalRescue(
                        id, animalName, species, location, ranger,
                        days, dailyCost, age, feedingCost, fosterCare);
                break;

            case 3:
                String classification = input.readRequiredText(
                        "Conservation Classification: ");

                double securityCost = input.readCost(
                        "Total Security Cost (R): ", true);

                boolean specialistTeam = input.readYesNo(
                        "Specialist Team Required");

                rescueCase = new EndangeredSpeciesRescue(
                        id, animalName, species, location, ranger,
                        days, dailyCost, classification,
                        securityCost, specialistTeam);
                break;

            default:
                throw new IllegalArgumentException(
                        "Unknown rescue type.");
        }

        if (manager.addRescueCase(rescueCase)) {
            System.out.println("\nRescue case created successfully.");
            System.out.println(rescueCase.generateRescueSummary());
        } else {
            System.out.println("A case with that ID already exists.");
        }
    }

    private static void searchRescueCase(InputHelper input,
                                         RescueManager manager) {
        String id = input.readRequiredText("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findRescueCase(id);

        if (rescueCase == null) {
            System.out.println("Rescue case not found.");
            return;
        }

        System.out.println("\n" + rescueCase.generateRescueSummary());
        System.out.println("Animal Name: " + rescueCase.getAnimalName());
        System.out.println(
                "Rescue Location: " + rescueCase.getRescueLocation());
        System.out.println("Rescue Days: " + rescueCase.getRescueDays());
        System.out.printf(
                "Daily Care Cost: R%.2f%n", rescueCase.getDailyCareCost());
        System.out.println(rescueCase.getSpecificDetails());
    }

    private static void updateRescueStatus(InputHelper input,
                                           RescueManager manager) {
        String id = input.readRequiredText("Enter Rescue Case ID: ");

        if (manager.findRescueCase(id) == null) {
            System.out.println("Rescue case not found.");
            return;
        }

        System.out.println("\n1. Start Rescue");
        System.out.println("2. Mark Under Observation");
        System.out.println("3. Complete Rescue");

        int choice = input.readInt("Select an option: ", 1, 3);

        switch (choice) {
            case 1:
                manager.startRescue(id);
                break;
            case 2:
                manager.updateRescueStatus(id, "Under Observation");
                break;
            case 3:
                manager.completeRescue(id);
                break;
            default:
                throw new IllegalArgumentException("Invalid status option.");
        }

        System.out.println("Rescue status updated successfully.");
    }
}
