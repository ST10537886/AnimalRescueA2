/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author maake
 */
package za.co.wildlife;

public abstract class RescueCase implements RescueOperations {

    private final String rescueCaseId;
    private final String animalName;
    private final String species;
    private final String rescueLocation;
    private final String assignedRanger;
    private final int rescueDays;
    private final double dailyCareCost;
    private String rescueStatus;

    public RescueCase(String rescueCaseId, String animalName,
                      String species, String rescueLocation,
                      String assignedRanger, int rescueDays,
                      double dailyCareCost) {

        this.rescueCaseId = requireText(rescueCaseId, "Rescue Case ID");
        this.animalName = requireText(animalName, "Animal name");
        this.species = requireText(species, "Species");
        this.rescueLocation = requireText(rescueLocation, "Rescue location");
        this.assignedRanger = requireText(assignedRanger, "Assigned ranger");

        if (rescueDays <= 0) {
            throw new IllegalArgumentException(
                    "Rescue days must be greater than zero.");
        }

        if (!Double.isFinite(dailyCareCost) || dailyCareCost <= 0) {
            throw new IllegalArgumentException(
                    "Daily care cost must be a finite number greater than zero.");
        }

        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.rescueStatus = "Pending";
    }

    private static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank.");
        }
        return value.trim();
    }

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getRescueDays() {
        return rescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getRescueStatus() {
        return rescueStatus;
    }

    public void setRescueStatus(String rescueStatus) {
        this.rescueStatus = requireText(rescueStatus, "Rescue status");
    }

    public double calculateBaseCost() {
        return rescueDays * dailyCareCost;
    }

    public abstract double calculateTotalCost();

    public abstract String determinePriority();

    public abstract String getRescueType();

    public abstract String getSpecificDetails();

    @Override
    public void startRescue() {
        setRescueStatus("Rescue in Progress");
    }

    @Override
    public void completeRescue() {
        setRescueStatus("Completed");
    }

    @Override
    public String generateRescueSummary() {
        return String.format(
                "Case ID: %s%n"
                + "Rescue Type: %s%n"
                + "Species: %s%n"
                + "Assigned Ranger: %s%n"
                + "Priority: %s%n"
                + "Status: %s%n"
                + "Total Rescue Cost: R%.2f%n",
                rescueCaseId,
                getRescueType(),
                species,
                assignedRanger,
                determinePriority(),
                rescueStatus,
                calculateTotalCost());
    }
}