/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlife;

/**
 *
 * @author maake
 */
public class OrphanedAnimalRescue extends RescueCase {

    private final int estimatedAgeMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;

    public OrphanedAnimalRescue(String rescueCaseId, String animalName,
                                String species, String rescueLocation,
                                String assignedRanger, int rescueDays,
                                double dailyCareCost, int estimatedAgeMonths,
                                double feedingCost, boolean fosterCareRequired) {

        super(rescueCaseId, animalName, species, rescueLocation,
              assignedRanger, rescueDays, dailyCareCost);

        if (estimatedAgeMonths < 0) {
            throw new IllegalArgumentException(
                    "Estimated age cannot be negative.");
        }

        if (!Double.isFinite(feedingCost) || feedingCost < 0) {
            throw new IllegalArgumentException(
                    "Feeding cost must be finite and cannot be negative.");
        }

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + feedingCost;

        if (fosterCareRequired) {
            total += 2500;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        // Assumption: foster care cases are High; other orphan cases are Medium.
        return fosterCareRequired ? "High" : "Medium";
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public String getSpecificDetails() {
        return String.format(
                "Estimated Age (Months): %d%n"
                + "Feeding Cost: R%.2f%n"
                + "Foster Care Required: %s%n",
                estimatedAgeMonths,
                feedingCost,
                fosterCareRequired ? "Yes" : "No");
    }
}
