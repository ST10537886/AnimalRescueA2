/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.co.wildlifesa;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import za.co.wildlife.EndangeredSpeciesRescue;
import za.co.wildlife.InjuredAnimalRescue;
import za.co.wildlife.OrphanedAnimalRescue;
import za.co.wildlife.RescueCase;
import za.co.wildlife.RescueManager;

/**
 *
 * @author maake
 */




public class RescueSystemTest {

    private InjuredAnimalRescue injured(String id, boolean surgery) {
        return new InjuredAnimalRescue(
                id, "Ellie", "African Elephant", "Kruger",
                "Ranger Dlamini", 3, 200,
                "Leg injury", 1000, surgery);
    }

    private OrphanedAnimalRescue orphaned(String id, boolean foster) {
        return new OrphanedAnimalRescue(
                id, "R hino".replace(" ", ""), "White Rhino", "Limpopo",
                "Ranger Nkosi", 4, 300,
                2, 800, foster);
    }

    private EndangeredSpeciesRescue endangered(String id,
                                                boolean specialist) {
        return new EndangeredSpeciesRescue(
                id, "Leo", "African Wild Dog", "Mpumalanga",
                "Ranger Mokoena", 5, 400,
                "Endangered", 3000, specialist);
    }

    @Test
    public void injuredCostIncludesSurgeryWhenRequired() {
        assertEquals(6600.0,
                injured("WR101", true).calculateTotalCost(), 0.001);
    }

    @Test
    public void injuredCostExcludesSurgeryWhenNotRequired() {
        assertEquals(1600.0,
                injured("WR101", false).calculateTotalCost(), 0.001);
    }

    @Test
    public void orphanedCostIncludesFosterCareWhenRequired() {
        assertEquals(4500.0,
                orphaned("WR102", true).calculateTotalCost(), 0.001);
    }

    @Test
    public void orphanedCostExcludesFosterCareWhenNotRequired() {
        assertEquals(2000.0,
                orphaned("WR102", false).calculateTotalCost(), 0.001);
    }

    @Test
    public void endangeredCostIncludesSpecialistWhenRequired() {
        assertEquals(13000.0,
                endangered("WR103", true).calculateTotalCost(), 0.001);
    }

    @Test
    public void endangeredCostExcludesSpecialistWhenNotRequired() {
        assertEquals(5000.0,
                endangered("WR103", false).calculateTotalCost(), 0.001);
    }

    @Test
    public void injuredPriorityMatchesOurRules() {
        assertEquals("Critical", injured("WR101", true).determinePriority());
        assertEquals("High", injured("WR102", false).determinePriority());
    }

    @Test
    public void orphanedPriorityMatchesOurRules() {
        assertEquals("High", orphaned("WR101", true).determinePriority());
        assertEquals("Medium", orphaned("WR102", false).determinePriority());
    }

    @Test
    public void endangeredPriorityMatchesOurRules() {
        assertEquals("Critical",
                endangered("WR101", true).determinePriority());
        assertEquals("High",
                endangered("WR102", false).determinePriority());
    }

    @Test
    public void allRescueTypesSupportStatusChanges() {
        RescueManager manager = new RescueManager();

        RescueCase[] cases = {
            injured("WR101", true),
            orphaned("WR102", true),
            endangered("WR103", true)
        };

        for (RescueCase rescueCase : cases) {
            String id = rescueCase.getRescueCaseId();
            assertTrue(manager.addRescueCase(rescueCase));
            assertEquals("Pending", rescueCase.getRescueStatus());

            assertTrue(manager.startRescue(id));
            assertEquals("Rescue in Progress", rescueCase.getRescueStatus());

            assertTrue(manager.updateRescueStatus(id, "Under Observation"));
            assertEquals("Under Observation", rescueCase.getRescueStatus());

            assertTrue(manager.completeRescue(id));
            assertEquals("Completed", rescueCase.getRescueStatus());
        }
    }

    @Test
    public void searchFindsExistingCase() {
        RescueManager manager = new RescueManager();
        RescueCase rescueCase = injured("WR101", true);
        manager.addRescueCase(rescueCase);

        assertSame(rescueCase, manager.findRescueCase("WR101"));
        assertSame(rescueCase, manager.findRescueCase(" wr101 "));
    }

    @Test
    public void searchReturnsNullForMissingCase() {
        RescueManager manager = new RescueManager();
        manager.addRescueCase(injured("WR101", true));

        assertNull(manager.findRescueCase("UNKNOWN"));
    }

    @Test
    public void duplicateIdsAreRejectedAcrossRescueTypes() {
        RescueManager manager = new RescueManager();
        RescueCase original = injured("WR101", true);

        assertTrue(manager.addRescueCase(original));
        assertFalse(manager.addRescueCase(orphaned("WR101", false)));
        assertFalse(manager.addRescueCase(endangered(" wr101 ", true)));

        assertEquals(1, manager.getTotalCases());
        assertSame(original, manager.findRescueCase("WR101"));
    }

    @Test
    public void totalCostIncludesAllRescueTypes() {
        RescueManager manager = new RescueManager();
        manager.addRescueCase(injured("WR101", true));
        manager.addRescueCase(orphaned("WR102", true));
        manager.addRescueCase(endangered("WR103", true));

        assertEquals(3, manager.getTotalCases());
        assertEquals(24100.0, manager.getTotalEstimatedCost(), 0.001);
    }
}
